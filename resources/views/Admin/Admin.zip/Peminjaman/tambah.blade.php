<div class="modal fade" id="modalTambah">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('peminjaman.store') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Peminjaman</h5>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <label>Kode Peminjaman</label>
                        <input type="text" name="pinjam_kode" class="form-control" readonly>
                    </div>

                    {{-- 🔥 PILIH RUANGAN --}}
                    <div class="mb-3">
                        <label> Ruangan</label>
                        <select name="customer" id="customer" class="form-control" required>
                            <option value="">-- Pilih Ruangan --</option>
                            @foreach($customer as $c)
                                <option value="{{ $c->customer_id }}">
                                    {{ $c->customer_nama }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>Tanggal Pinjam</label>
                        <input type="date" name="tanggal" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label>Tanggal Jatuh Tempo</label>
                        <input type="date" name="jatuh_tempo" class="form-control" required>
                    </div>

                    {{-- 🔥 BARANG DINAMIS --}}
                    <div class="mb-3">
                        <label>Barang</label>
                        <select name="barang[]" id="barang" class="form-control" required>
                            <option value="">-- Pilih Barang --</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>Jumlah</label>
                        <input type="number" name="jumlah[]" min="1" class="form-control" required>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- 🔥 SCRIPT AJAX --}}
<script>
$('#customer').on('change', function () {
    let customer_id = $(this).val();
    let barang = $('#barang');

    barang.empty();
    barang.append('<option value="">-- Pilih Barang --</option>');

    if (!customer_id) return;

    $.get(`/admin/peminjaman/barang-by-ruangan/${customer_id}`, function (data) {
        if (data.length === 0) {
            barang.append('<option value="">Barang tidak tersedia</option>');
            return;
        }

        data.forEach(function (item) {
            barang.append(`
                <option value="${item.barang_kode}">
                    ${item.barang_nama} (stok: ${item.stok})
                </option>
            `);
        });
    });
});
</script>
