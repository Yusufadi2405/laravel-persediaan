@extends('Master.Layouts.app', ['title' => $title])

@section('content')
<div class="page-header">
    <h1 class="page-title">{{$title}}</h1>
    <div>
        <ol class="breadcrumb">
            <li class="breadcrumb-item text-gray">Transaksi</li>
            <li class="breadcrumb-item active">{{$title}}</li>
        </ol>
    </div>
</div>

<div class="row row-sm">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header justify-content-between">
                <h3 class="card-title">Data Peminjaman</h3>
                <div>
                    <a class="modal-effect btn btn-primary-light"
                       onclick="generateID()"
                       data-bs-toggle="modal"
                       href="#modalTambah">
                        Tambah Data <i class="fe fe-plus"></i>
                    </a>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table id="table-1" class="table table-bordered text-nowrap">
                        <thead>
                            <tr>
                                <th width="1%">No</th>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Tanggal Pinjam</th>
                                <th>Tanggal Dikembalikan</th>
                                <th>Barang</th>
                                <th>Jumlah</th>
                                <th>Status</th>
                                <th width="1%">Action</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

@include('Admin.Peminjaman.tambah')
@include('Admin.Peminjaman.hapus')
@endsection
@section('scripts')
<script>
function generateID(){
    let kode = "PMJ-" + Date.now();
    $("input[name='pinjam_kode']").val(kode);
}

// 🔥 KEMBALIKAN
function kembalikan(id) {
    if (!confirm('Yakin ingin mengembalikan barang ini?')) return;

    $.ajax({
        url: "{{ route('peminjaman.kembalikan', ':id') }}".replace(':id', id),
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}'
        },
        success: function () {
            $('#table-1').DataTable().ajax.reload(null, false);
        },
        error: function () {
            alert('Gagal mengembalikan barang');
        }
    });
}

// 🔥 HAPUS
function hapus(data){
    $("input[name='idpeminjaman']").val(data.pinjam_id);
    $("#vpeminjaman").html("<b>" + data.pinjam_kode + "</b>");
    $("#modalHapus").modal('show');
}

$(document).ready(function () {

    // 🔥 DATATABLE
    $('#table-1').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('peminjaman.get') }}",
        ordering: false,
        columns: [
            { data: 'DT_RowIndex', orderable: false, searchable: false },
            { data: 'pinjam_kode' },
            { data: 'customer' },
            { data: 'pinjam_tanggal' },
            { data: 'tanggal_dikembalikan' },
            { data: 'barang', orderable: false, searchable: false },
            { data: 'jumlah', orderable: false, searchable: false },
            { data: 'pinjam_status' },
            { data: 'action', orderable: false, searchable: false }
        ]
    });

    // 🔥 BARANG BY RUANGAN
    $(document).on('change', '#customer', function () {

        let customer_id = $(this).val();
        let barang = $('#barang');

        barang.html('<option value="">-- Pilih Barang --</option>');

        if (!customer_id) return;

        let url = "{{ route('peminjaman.barang.by.ruangan', ':id') }}";
        url = url.replace(':id', customer_id);

        $.get(url, function (data) {
            console.log('DATA BARANG:', data);

            if (data.length === 0) {
                barang.append('<option value="">Barang tidak tersedia</option>');
                return;
            }

            data.forEach(function (item) {
                barang.append(`
                    <option value="${item.barang_kode}">
                        ${item.barang_nama} (stok: ${item.stok})
                    </option>
                `);
            });
        });
    });

});
</script>
@endsection
